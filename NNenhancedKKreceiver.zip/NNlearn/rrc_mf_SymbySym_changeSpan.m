%% ��֤rrcƥ���˲��ĳ��ȶ����ܵ�Ӱ��
clear all;
close all;
clc;
load PRBS;
% span_tran=8;
beta=0.1;
span_rec=[256,128,64,32,16,8,4];
span_tran=span_rec;
ModulateFormat='qam';
NperSym=4;
TranRrcLen=span_tran*NperSym;
RecRrcLen=span_rec*NperSym;
osnr=0:0.5:25;
M=16;
BitLen=length(PRBS);
SymLen=BitLen/log2(M);
ber_mf=zeros(length(span_rec),length(osnr));
% ber_nn=zeros(length(span_rec),length(osnr));
% RxSignal_bySym=zeros(TranRrcLen+1,length(PRBS)/log2(M));
% Rxbits=zeros(1,length(PRBS));
%% �������
% net=feedforwardnet(10);
%% �źŵ���
TxSymbol=SymbolModulate(PRBS,ModulateFormat,M);
% rrc_tran=rcosdesign(beta,span_tran,NperSym,'sqrt');
% TxSignal=conv(TxSymbol,rrc_tran);
% TxSignal = rrcu(TxSymbol, beta, NperSym, span_tran); 
%% ����
for p=1:length(span_tran)
    TxSignal = rrcu(TxSymbol, beta, NperSym, span_tran(p)); 
% for q=1:51
%     RxSignal=awgn(TxSignal,osnr(q),'measured');
%% ѵ������
% for t=1:4:length(RxSignal)-TranRrcLen
%     RxSignal_bySym(:,round(t/4)+1)= RxSignal(t:t+TranRrcLen)';
% end
% P=RxSignal_bySym(:,1:SymLen/4);
% P=[real(P);imag(P)];
% T=TxSymbol(:,1:SymLen/4);
% T=[real(T);imag(T)];
%% ѵ��������
% net=train(net,P,T);
%% ����������
% simdatain=RxSignal_bySym(:,SymLen/4+1:end);
% simdatain=[real(simdatain);imag(simdatain)];
% simdataout=sim(net,simdatain);
% simdataout=simdataout(1,:)+1j*simdataout(2,:);
% Nnbits=SymbolDemodulate(simdataout,ModulateFormat,M);
%% ƥ���˲�
% rrc_rec=rcosdesign(beta,span_rec(p),NperSym,'sqrt');
% rrc_rec=rrc_rec(end:-1:1);       %ʱ�䷴��
% RxSymbol=conv(RxSignal,rrc_rec);
RxSymbol = rrcmd(TxSignal, beta, NperSym, span_rec(p));
% offset=0;
% RxSymbol = downsample(RxSymbol,NperSym,offset);
figure(p)
plot(RxSymbol,'.');
% Rxbits=SymbolDemodulate(RxSymbol(RecRrcLen(p)/4+1:end-RecRrcLen(p)/4),ModulateFormat,M);
%% �����ʼ���
% [~,ber_mf(p,q)]=biterr(Rxbits(BitLen/4+1:end),PRBS(BitLen/4+1:end));
% [~,ber_nn(p,q)]=biterr(Nnbits,PRBS(BitLen/4+1:end));
% end
%% ��BER-SNRͼ
% semilogy(osnr(1:q),ber_mf(p,1:q));
% hold on;
% semilogy(osnr(1:q),ber_nn(p,1:q));
% hold on;
end
%% ͼ����
% title('��ͬ����span�µ�BER-SNRͼ');
% % title('BP�������ƥ���˲����ܶԱ�ͼ')
% legend('256','128','64','32','16','8','4');
% % legend('ƥ���˲�','BP������');
% grid on;
% xlabel('SNR');
% ylabel('BER');