%% ��֤rrcƥ���˲��ĳ��ȶ����ܵ�Ӱ��
clear all;
close all;
clc;
load PRBS;
span_tran= 32 ;
fs = 100;
for beta=[0.01 0.1 0.5 1.0]
span_rec=[256,128,64,32,16,8,4,2];
ModulateFormat='qam';
NperSym=4;
osnr=0:0.5:25;
M=4;
ber=zeros(length(span_rec),length(osnr));
% Rxbits=zeros(1,length(PRBS));
%% �źŵ���
TxSymbol=SymbolModulate(PRBS,ModulateFormat,M);
% rrc_tran=rcosdesign(beta,span_tran,NperRange,'sqrt');
% TxSignal=conv(TxSymbol,rrc_tran,'same');
TxSignal = rrc(TxSymbol, beta, NperSym, span_tran); 
%% ����
for p = 4
for q=1:51
RxSignal=awgn(TxSignal,osnr(q),'measured');
B = (1+beta)*0.5*fs/NperSym;
RxSignal = IdealFilter(RxSignal,fs,B,0);
%% ƥ���˲�
% rrc_rec=rcosdesign(beta,span_rec(p),NperRange,'sqrt');
% rrc_rec=rrc_rec(end:-1:1);       %ʱ�䷴��
% RxSymbol=conv(RxSignal,rrc_rec,'same');
RxSymbol = rrcm(RxSignal, beta, NperSym, span_rec(p));
offset=0;
RxSymbol = downsample(RxSymbol,NperSym,offset);
Rxbits=SymbolDemodulate(RxSymbol,ModulateFormat,M);
%% �����ʼ���
[~,ber(p,q)]=biterr(Rxbits,PRBS);
end
semilogy(osnr(1:q),ber(p,1:q));
hold on;
end
end
%% ͼ����
title('��ͬ����span�µ�BER-SNRͼ');
% legend('256','128','64','32','16','8','4','2');
grid on;
xlabel('SNR');
ylabel('BER');