function filsignal = SincFilter(orisignal,fs,band,center)
