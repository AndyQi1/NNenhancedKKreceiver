%% ��֤��ͨƥ���˲�����
% clc;
clear all;
close all
fs = 100;
ts = 1/fs;
NperSym = 4;
M = 16;
load PRBS;
ModulateFormat = 'qam';
bd = 'rsb';
PulseShapeFlag = 'rrc';
beta = 0.1;
span = 32;
RrcLen=NperSym*span;
head = 8;
tail = 8;
BitLen=length(PRBS);
SymLen=BitLen/log2(M);
osnr = 15;
mag = 0.6;
useKK = 1;
useNN = 1;
TrainSymRatio = 1/2;  % ѵ������ռ�����ݵı�ֵ
TrainSymLen=TrainSymRatio*SymLen;

TxSymbol = SymbolModulate(PRBS, ModulateFormat, M);
TxSignal = rrcu(TxSymbol, beta, NperSym, span);  % ������������ͣ��ڴ��ϲ���
plotSpec(TxSignal,fs,'�����ź�Ƶ��');
B = (1+beta)*0.5*fs/NperSym;

for B = B

t = [1:length(TxSignal)]*ts;
TxSignal_shift = TxSignal.*exp(1j*2*pi*B*t);
theta = pi/10;
interval = 0;
A = mag*max(abs(TxSignal_shift))*exp(1j*theta);
% bsht = awgn(TxSignal_shift,osnr,'measured');
bsht = TxSignal_shift;
bsht = IdealFilter(bsht,fs,(1+beta)*0.5*fs/NperSym,B) + A;
plotSpec(bsht,fs,'��С��λ�ź�');
I = bsht.*conj(bsht);
% I =  bsht - A;
plotSpec(I,fs,'PD̽��Ƶ��');
if useKK
    I = getssb(I,'rsb');
    I = I-mean(I);
    plotSpec(I,fs,'KK�ָ��ź�Ƶ��');
else
    I = IdealFilter(I,fs,(1+beta)*0.5*fs/NperSym,B);
    plotSpec(I,fs,'�˲���Ƶ��');
end
RxSignal = I.*exp(-j*2*pi*B*t);
plotSpec(RxSignal,fs,'�����ź�Ƶ��');
RxSignal_resample = resample(RxSignal,1,1);
ReSampleRate = 1;
plotSpec(RxSignal_resample,fs,'�ز����ź�Ƶ��');
% figure
% ang = angle(fftshift((fft(RxSignal))));
% plot(ang(1:20));
if useNN 
    LayerPoints = [64 32];
    net1 = patternnet(LayerPoints);
    net1.trainParam.max_fail = 20;
    net1.performParam.regularization = 0.05;
    net1.performParam.normalization = 'none';
    net1.divideParam.trainRatio = 0.6;
    net1.divideParam.valRatio = 0.25;
    net1.divideParam.testRatio = 0.15;
    net1 = init(net1);
    RrcLen_resample = round(RrcLen*ReSampleRate);
    NperSym_resample = round(NperSym*ReSampleRate);
    for r=1:NperSym_resample:length(RxSignal_resample)-RrcLen_resample
    RxSignal_bySym(:,round(r/NperSym_resample)+1)= RxSignal_resample(r:r+RrcLen_resample)';
    end
    RxSignal_bySym = RxSignal_bySym(RrcLen_resample*14/32:RrcLen_resample*18/32,:);
    RealPart = real(RxSignal_bySym);  %% ���Խ���Ӧ��ʵ�����鲿����һ��
    ImagPart = imag(RxSignal_bySym);
    MagPart = abs(RxSignal_bySym);
    for v = 1:SymLen
    RealMixPart(:,v) = conv(RealPart(:,v),RealPart(:,v));
    ImagMixPart(:,v) = conv(ImagPart(:,v),ImagPart(:,v));
    RealImagMixPart(:,v) = conv(RealPart(:,v),ImagPart(:,v));
    end
%     RxSignal_qam = [];
%     for v=1:RrcLen_resample+1
%         RxSignal_qam = [RxSignal_qam;RealPart(v,:);ImagPart(v,:)];
%     end
    RxSignal_train = [RealPart;ImagPart;RealMixPart;ImagMixPart;RealImagMixPart];
    P = RxSignal_train(:,1:TrainSymLen);
    Vec=getvec(PRBS,M);
    T=Vec(:,1:TrainSymLen);
    
    net1 = train(net1,P,T);
    
    simdatain=RxSignal_train(:,TrainSymLen+1:end);
    simdataout=sim(net1,simdatain);
    NnBits = getbin(simdataout,M);
end

RxSymbol = rrcmd(RxSignal, beta, NperSym, span);
RxSymbol = RxSymbol(RrcLen/NperSym+1:end-RrcLen/NperSym);
plotSpec(RxSignal,fs,'ƥ���˲����ź�Ƶ��');
% offset = 0;
% RxSymbol = downsample(RxSignal, NperSym, offset);
tha = theta;
RxSymbol = RxSymbol.*exp(j*tha);
figure
plot(RxSymbol(TrainSymLen+1:end),'.');
RxBits = SymbolDemodulate(RxSymbol(TrainSymLen+1:end), ModulateFormat, M);
TxBits = SymbolDemodulate(TxSymbol(TrainSymLen+1:end), ModulateFormat, M);
BitLength = length(RxBits);
[ErrNum_mf,BER_mf,~] = biterr(RxBits(1:BitLength),TxBits(1:BitLength));
[BER_mf,B]
if useNN
     [ErrNum_nn,BER_nn,~] = biterr(NnBits(1:BitLength),TxBits(1:BitLength));
     BER_nn
end
% [BER,B,ang(1)]
% pause
% close all
end