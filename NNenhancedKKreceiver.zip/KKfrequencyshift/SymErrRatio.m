%% ��������ض���ߺ��ұ߷��ŵ�Ŀ����Ŵ�����
function TargetSymErrRatio = SymErrRatio(OriSym,RecSym,Left,Center,Right)
SymLen = length(OriSym);
SymBatch = [Left,Center,Right];
LeftLen = length(Left);
CenterLen = length(Center);
RightLen = length(Right);
SymBatchLen = LeftLen + RightLen + CenterLen;
TargetOriSym = [];
TargetRecSym = [];
for p = 1 : SymLen - SymBatchLen + 1
    if sum(OriSym(p:p+SymBatchLen-1) == SymBatch(1:end))== 3
        TargetOriSym = [TargetOriSym,OriSym(p+LeftLen:p+LeftLen+CenterLen-1)];
        TargetRecSym = [TargetRecSym,RecSym(p+LeftLen:p+LeftLen+CenterLen-1)];
    end 
end
TargetSymLen = length(TargetOriSym);
if TargetSymLen == 0
    TargetSymErrRatio = 0;
else
TargetSymErrRatio = sum(TargetOriSym ~= TargetRecSym)/TargetSymLen;
end
% ErrSym = TargetOriSym(TargetOriSym ~= TargetRecSym);
