function outSignal = MyAlgorithm(inSignal,re,mag)
InRealPart = real(inSignal);
InImagPart = imag(inSignal);
for qq = 1:length(inSignal)
    
    % ʵ��
    
    if abs(InRealPart(qq)) >0.5 && abs(InRealPart(qq))<1 && rand >1-mag/2
        InRealPart(qq) = InRealPart(qq)*1.5;
        if abs(InRealPart(qq)) > 2
            InRealPart(qq) = sign(InRealPart(qq)).*2;
        end
        continue
    end
    if abs(InRealPart(qq)) >1 && rand < mag/2
        InRealPart(qq) = InRealPart(qq)*1.5;
        if abs(InRealPart(qq)) > 2
            InRealPart(qq) = sign(InRealPart(qq)).*2;
        end
        continue
    end
    if abs(InRealPart(qq)) > 0.5 && abs(InRealPart(qq)) <1 && rand<mag/2
        InRealPart(qq) = InRealPart(qq)*0.7;
        if abs(InRealPart(qq)) > 2
            InRealPart(qq) = sign(InRealPart(qq)).*2;
        end
        continue
    end
    if abs(InRealPart(qq)) < 0.5 && rand < mag/2
        InRealPart(qq) = InRealPart(qq)*0.7;
        if abs(InRealPart(qq)) > 2
            InRealPart(qq) = sign(InRealPart(qq)).*2;
        end
        continue
    end
    if abs(InRealPart(qq)) < 0.3 && rand < mag/2
        InRealPart(qq) = sign(InRealPart(qq))*InRealPart(qq).^2;
        if abs(InRealPart(qq)) > 2
            InRealPart(qq) = sign(InRealPart(qq)).*2;
        end
        continue
    end
    if abs(InRealPart(qq)) > 1 && rand < mag/2
        InRealPart(qq) = sign(InRealPart(qq))*InRealPart(qq).^2;
        if abs(InRealPart(qq)) > 2
            InRealPart(qq) = sign(InRealPart(qq)).*2;
        end
        continue
    end
    if abs(InRealPart(qq))<1.5 && abs(InRealPart(qq))>0.5 && rand > 1-mag/2
        InRealPart(qq) = -InRealPart(qq);
        if abs(InRealPart(qq)) > 2
            InRealPart(qq) = sign(InRealPart(qq)).*2;
        end
        continue
    end
    if rand > 0.95
        InRealPart(qq) = rand*InRealPart(qq); 
        if abs(InRealPart(qq)) > 2
            InRealPart(qq) = sign(InRealPart(qq)).*2;
        end
        continue
    end
    
    % �鲿
    
    if abs(InImagPart(qq)) >0.5 && abs(InImagPart(qq))<1 && rand >1-mag/2
        InImagPart(qq) = InImagPart(qq)*1.5;
        if abs(InImagPart(qq)) > 2
            InImagPart(qq) = sign(InImagPart(qq)).*2;
        end
        continue
    end
    if abs(InImagPart(qq)) >1 && rand > mag
        InImagPart(qq) = InImagPart(qq)*1.5;
        if abs(InImagPart(qq)) > 2
            InImagPart(qq) = sign(InImagPart(qq)).*2;
        end
        continue
    end
    if abs(InImagPart(qq)) > 0.5 && abs(InImagPart(qq)) <1 && rand<mag/2
        InImagPart(qq) = InImagPart(qq)*0.7;
        if abs(InImagPart(qq)) > 2
            InImagPart(qq) = sign(InImagPart(qq)).*2;
        end
        continue
    end
    if abs(InImagPart(qq)) < 0.5 && rand < mag/2
        InImagPart(qq) = InImagPart(qq)*0.7;
        if abs(InImagPart(qq)) > 2
            InImagPart(qq) = sign(InImagPart(qq)).*2;
        end
        continue
    end
    if abs(InImagPart(qq)) < 0.3 && rand < mag/2
        InImagPart(qq) = sign(InImagPart(qq))*InImagPart(qq).^2;
        if abs(InImagPart(qq)) > 2
            InImagPart(qq) = sign(InImagPart(qq)).*2;
        end
        continue
    end
    if abs(InImagPart(qq)) > 1 && rand > mag
        InImagPart(qq) = sign(InImagPart(qq))*InImagPart(qq).^2;
        if abs(InImagPart(qq)) > 2
            InImagPart(qq) = sign(InImagPart(qq)).*2;
        end
        continue
    end
    if abs(InImagPart(qq))<1.5 && abs(InImagPart(qq))>0.5 && rand > 1-mag/2
        InImagPart(qq) = -InImagPart(qq);
        if abs(InImagPart(qq)) > 2
            InImagPart(qq) = sign(InImagPart(qq)).*2;
        end
        continue
    end
    if rand > 0.95
        InImagPart(qq) = rand*InImagPart(qq); 
        if abs(InImagPart(qq)) > 2
            InImagPart(qq) = sign(InImagPart(qq)).*2;
        end
        continue
    end
end
InRealPart = tansig(InRealPart);
InImagPart = tansig(InImagPart);    
InRealPart(abs(InRealPart)>0.5) = InRealPart(abs(InRealPart)>0.5).*1.5;
InImagPart(abs(InImagPart)>0.5) = InImagPart(abs(InImagPart)>0.5).*1.5;
InRealPart(abs(InRealPart)>1) = sign(InRealPart(abs(InRealPart)>1)).*InRealPart(abs(InRealPart)>1).^2;
InImagPart(abs(InImagPart)>1) = sign(InImagPart(abs(InImagPart)>1)).*InImagPart(abs(InImagPart)>1).^2;
InRealPart(abs(InRealPart)>2) = sign(InRealPart(abs(InRealPart)>2)).*2;
InImagPart(abs(InImagPart)>2) = sign(InImagPart(abs(InImagPart)>2)).*2;
OutRealPart = InRealPart;
OutImagPart = InImagPart;
if re == 1
    OutRealPart = mapminmax(OutRealPart,min(min(real(inSignal))),max(max(real(inSignal))));
    OutImagPart = mapminmax(OutImagPart,min(min(imag(inSignal))),max(max(imag(inSignal))));
end
outSignal = OutRealPart + j*OutImagPart;
    