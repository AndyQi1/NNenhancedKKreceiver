close all;
fs = 100;
t = randi(2,1,1024)-1;
t = IdealFilter(t,fs,24,25.5);
% t = ((t)-1).^2;
hil = imag(hilbert(real(t)));
ImagPart = imag(t);
max(ImagPart - hil)
min(ImagPart - hil)
plotSpec(log(t),fs);