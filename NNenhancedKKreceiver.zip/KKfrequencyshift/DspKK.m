function kksignal = DspKK(I,A)
% oriLen = length(I);
% I = resample(I,3,2);
% length(I)
rootI = sqrt(I);
rootH = 2*rootI/A - 1/2*I/(A^2);
HilTran = imag(hilbert(rootH));
RealPart = rootI - 1/2*A*HilTran.^2 ;
% RealPart = RealPart - mean(RealPart);
ImagPart = imag(hilbert(RealPart));
kksignal = RealPart + j*ImagPart;
kksignal = kksignal - mean(kksignal);
% kksignal = resample(kksignal,2,3);
% kksignal = kksignal(1:oriLen);