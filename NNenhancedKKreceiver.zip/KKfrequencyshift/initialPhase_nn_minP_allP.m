%% ��֤��ͨƥ���˲�����
clc;
clear all;
close all
fs = 100;
ts = 1/fs;
NperSym = 4;
M = 16;
load PRBS;
% PRBS = PRBS_1M;
% PRBS = randi(2,1,2^20)-1;
ModulateFormat = 'qam';
bd = 'rsb';
PulseShapeFlag = 'rrc';
beta = 0.1;
span = 32;
RrcLen=NperSym*span;
head = 8;
tail = 8;
BitLen=length(PRBS);
SymLen=BitLen/log2(M);
osnr = 25;
for mag = 0.6
for useKK = 1
useNN = 0;
for ReduceSSBI = 0
BER_mf_mat = [];
BER_nn_mat = [];
for q = 1:length(osnr)
TrainSymRatio = 1/2;  % ѵ������ռ�����ݵı�ֵ
TrainSymLen=TrainSymRatio*SymLen;
TxSymbol = SymbolModulate(PRBS, ModulateFormat, M);
TxSignal = rrcu(TxSymbol, beta, NperSym, span);  % ������������ͣ��ڴ��ϲ���
% plotSpec(TxSignal,fs,'�����ź�Ƶ��');
B = (1+beta)*0.5*fs/NperSym;
for B = B
TotalNnErrNum = 0;
TotalMfErrNum = 0;
t = [1:length(TxSignal)]*ts;
TxSignal_shift = TxSignal.*exp(1j*2*pi*B*t);
theta = 0;
for StartSel = 1
phaseT = 1;
A = mag*max(abs(TxSignal_shift))*exp(1j*theta);
bsht = awgn(TxSignal_shift,osnr(q),'measured');
bsht = IdealFilter(bsht,fs,(1+beta)*0.5*fs/NperSym,B) + A;
% plotSpec(bsht,fs,'��С��λ�ź�');
I = bsht.*conj(bsht);
% plotSpec(I,fs,'PD̽��Ƶ��');
if useKK == 1
    I = resample(I,2,1);
    minP = IdealFilter(log(I),fs,24.5,25);
    plotSpec((minP),fs);
    allP = I./minP;
    plotSpec((allP),fs);
    allP = -imag(hilbert(-real(allP)));
    allP = sqrt(I).*exp(j*allP);
    allP = resample(allP,1,2);
    allP = allP - mean(allP);
    minP = imag(hilbert(real(minP)));
    minP = sqrt(I).*exp(j*minP);
    minP = resample(minP,1,2);
    minP = minP - mean(minP);
    X_Out = minP;
    minP = minP.*exp(-1j*B*2*pi*t);
    allP = allP.*exp(-1j*B*2*pi*t);
%     plotSpec(X_Out,fs,'KK�ָ��ź�Ƶ��');
    if ReduceSSBI
    X_SSBI = I - abs(X_Out).^2;
    X_SSBI = X_SSBI - mean(X_SSBI);
%     plotSpec(X_SSBI,fs,'�޸���䴮���˲�֮ǰ���ź�Ƶ��');
    X_SSBI = IdealFilter(X_SSBI,fs,(1+beta)*0.5*fs/NperSym,B);
%     plotSpec(X_SSBI,fs,'�޸���䴮���˲�����ź�Ƶ��');
    X_Out = X_SSBI/A;
    end
elseif useKK == 0
    X_Out = IdealFilter(I,fs,(1+beta)*0.5*fs/NperSym,B);
%     plotSpec(X_Out,fs,'�˲���Ƶ��');
else
    X_Out = DspKK(X_Out,A);
    X_Out = IdealFilter(X_Out,fs,(1+beta)*0.5*fs/NperSym,B);
%     plotSpec(X_Out,fs,'KK�ָ��ź�Ƶ��');
end
RxSignal = X_Out.*exp(-j*2*pi*B*t);
% plotSpec(RxSignal,fs,'�����ź�Ƶ��');
% RxSignal_resample = resample(RxSignal,1,1);
% ReSampleRate = 1;
% plotSpec(RxSignal_resample,fs,'�ز����ź�Ƶ��');
if useNN 
    LayerPoints = [64 32];
    net1 = patternnet(LayerPoints);
%     net1 = feedforwardnet(LayerPoints,'trainscg');
%     net1.layers{3}.transferFcn = 'tansig';
    net1.trainParam.max_fail = 20;
    net1.performParam.regularization = 0.05;
    net1.performParam.normalization = 'none';
    net1.divideParam.trainRatio = 0.6;
    net1.divideParam.valRatio = 0.25;
    net1.divideParam.testRatio = 0.15;
    net1 = init(net1);
    minP_bySym = [];
    allP_bySym = [];
    for r=1:NperSym:length(allP)-RrcLen
    minP_bySym(:,round(r/NperSym)+1)= minP(r:r+RrcLen)';
    allP_bySym(:,round(r/NperSym)+1)= allP(r:r+RrcLen)';
    end
%     minP_bySym = minP_bySym(RrcLen*16/32-8:RrcLen*16/32+8,:);
%     allP_bySym = allP_bySym(RrcLen*16/32-8:RrcLen*16/32+8,:);
%     RxSignal_bySym = PreSignalProcess(RxSignal_bySym,0);
    
    minPRealPart = real(minP_bySym);  %% ���Խ���Ӧ��ʵ�����鲿����һ��
    minPImagPart = imag(minP_bySym);
    allPRealPart = real(allP_bySym);
    allPImagPart = imag(allP_bySym);
    RxSignal_train = [minPRealPart;minPImagPart;allPRealPart;allPImagPart];
    P = RxSignal_train(:,StartSel:phaseT:TrainSymLen);
    Vec=getvec(PRBS,M);
    T=Vec(:,StartSel:phaseT:TrainSymLen);
    
    net1 = train(net1,P,T);
    
    simdatain=RxSignal_train(:,TrainSymLen+StartSel:phaseT:end);
    simdataout=sim(net1,simdatain);
    NnBits = getbin(simdataout,M);
end

RxSymbol = rrcmd(RxSignal, beta, NperSym, span);
RxSymbol = RxSymbol(RrcLen/NperSym+1:end-RrcLen/NperSym);
% plotSpec(RxSignal,fs,'ƥ���˲����ź�Ƶ��');
% figure
% plot(RxSymbol(TrainSymLen+1:phaseT:end),'.');
RxBits = SymbolDemodulate(RxSymbol(TrainSymLen+StartSel:phaseT:end), ModulateFormat, M);
TxBits = SymbolDemodulate(TxSymbol(TrainSymLen+StartSel:phaseT:end), ModulateFormat, M);
BitLength = length(RxBits);
[ErrNum_mf,BER_mf,~] = biterr(RxBits(1:BitLength),TxBits(1:BitLength));
[BER_mf,B]
if useNN
     [ErrNum_nn,BER_nn,~] = biterr(NnBits(1:BitLength),TxBits(1:BitLength));
     BER_nn
end
if useNN
TotalNnErrNum = ErrNum_nn + TotalNnErrNum;
end
TotalMfErrNum = ErrNum_mf + TotalMfErrNum;
end
if useNN
    BER_nn = TotalNnErrNum/(BitLen*TrainSymRatio);
    BER_nn_mat = [BER_nn_mat BER_nn];
end
BER_mf = TotalMfErrNum/(BitLen*TrainSymRatio);
BER_mf_mat = [BER_mf_mat BER_mf];
end
end
% figure(1)
% if useNN
% semilogy(osnr,BER_nn_mat);
% hold on;
% end
% semilogy(osnr,BER_mf_mat);
% hold on;
% xlabel('OSNR');
% ylabel('BER');
% grid on;
end
end
end