function outSignal = PreSignalProcess(inSignal,re)
InRealPart = tansig(real(inSignal));
InImagPart = tansig(imag(inSignal));
InRealPart(abs(InRealPart)>0.5) = InRealPart(abs(InRealPart)>0.5).*1.5;
InImagPart(abs(InImagPart)>0.5) = InImagPart(abs(InImagPart)>0.5).*1.5;
InRealPart(abs(InRealPart)>1) = sign(InRealPart(abs(InRealPart)>1)).*InRealPart(abs(InRealPart)>1).^2;
InImagPart(abs(InImagPart)>1) = sign(InImagPart(abs(InImagPart)>1)).*InImagPart(abs(InImagPart)>1).^2;
InRealPart(abs(InRealPart)>2) = sign(InRealPart(abs(InRealPart)>2)).*2;
InImagPart(abs(InImagPart)>2) = sign(InImagPart(abs(InImagPart)>2)).*2;
OutRealPart = InRealPart;
OutImagPart = InImagPart;
if re == 1
    OutRealPart = mapminmax(OutRealPart,min(min(real(inSignal))),max(max(real(inSignal))));
    OutImagPart = mapminmax(OutImagPart,min(min(imag(inSignal))),max(max(imag(inSignal))));
end
outSignal = OutRealPart + j*OutImagPart;
    