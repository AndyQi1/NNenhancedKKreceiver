%% KK

function ssb = getssb(I,type,theta)
if nargin < 3
    theta = 0;
end
I = resample(I,2,1);
I1 = log(I);
I1 = imag(hilbert(real(I1)));  

phase = theta + I1/(2);
if strcmpi(type,'lsb')==1
    ssb = conj(sqrt(I).*exp(1j*phase));
else if strcmpi(type,'rsb')==1
    ssb = (sqrt(I).*exp(1j*phase));
    end
end
ssb = resample(ssb,1,2);






% function ssb = getssb(I,type,E0,B,ts);
% 
% I1 = hilbert(I);
% I1 = log2(I1);
% phase = pi*I1/2;
% t = [1:length(I)]*ts;
% if 'lsb' == type
%     ssb = conj(sqrt(I).*exp(j*phase)-E0).*exp(j*pi*B*t);
% else if 'rsb' == type
%     ssb = (sqrt(I).*exp(j*phase)-E0)%.*exp(-j*pi*B*t);
%     end
% end