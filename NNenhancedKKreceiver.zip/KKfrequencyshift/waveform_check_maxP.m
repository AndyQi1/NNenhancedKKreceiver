%% kk�㷨����,������������µ�KK�㷨�ܷ���ʸ���źţ��Ƿ�����ͼΪ������
% clc;
clear all;
% close all

fs = 100;
ts = 1/fs;

NperSym = 4;
M = 16;      % ���ƽ�������ƽ������
beta = 0.1;
span = 32;
RrcLen=NperSym*span;
rc = rcosdesign(beta,span,NperSym,'sqrt');     % ������
yt = zeros(1,length(rc)+NperSym*16);

kk=3; yt(kk*NperSym+1:kk*NperSym+length(rc)) = yt(kk*NperSym+1:kk*NperSym+length(rc))+(+3-j*3)*rc;
kk=4; yt(kk*NperSym+1:kk*NperSym+length(rc)) = yt(kk*NperSym+1:kk*NperSym+length(rc))+(-3+j*3)*rc;
kk=5; yt(kk*NperSym+1:kk*NperSym+length(rc)) = yt(kk*NperSym+1:kk*NperSym+length(rc))+(-3+j*3)*rc;
kk=6; yt(kk*NperSym+1:kk*NperSym+length(rc)) = yt(kk*NperSym+1:kk*NperSym+length(rc))+(-3+j*3)*rc;

% kk=12; yt(kk*NperSym+1:kk*NperSym+length(rc)) = yt(kk*NperSym+1:kk*NperSym+length(rc))+(-1+j*1)*rc;

kk=13; yt(kk*NperSym+1:kk*NperSym+length(rc)) = yt(kk*NperSym+1:kk*NperSym+length(rc))+(+3-j*3)*rc;
kk=14; yt(kk*NperSym+1:kk*NperSym+length(rc)) = yt(kk*NperSym+1:kk*NperSym+length(rc))+(-3+j*3)*rc;
kk=15; yt(kk*NperSym+1:kk*NperSym+length(rc)) = yt(kk*NperSym+1:kk*NperSym+length(rc))+(-3+j*3)*rc;
kk=16; yt(kk*NperSym+1:kk*NperSym+length(rc)) = yt(kk*NperSym+1:kk*NperSym+length(rc))+(-3+j*3)*rc;

% kk=7; yt(kk*NperSym+1:kk*NperSym+length(rc)) = yt(kk*NperSym+1:kk*NperSym+length(rc))+(+3+j*3)*rc;
theta = 0;
mag = 10;
A = mag*max(abs(yt))*exp(j*theta);

B = (1+beta)*0.5*fs/NperSym;
B = B;
% t = [23+1:23+length(yt)]*ts;
t = [0+1:0+length(yt)]*ts;
yt_shift = yt.*exp(1j*2*pi*B*t);
% yta = yt_shift + A*exp(j*pi*0.5);
yta = yt_shift + A*exp(j*pi*0);
I = abs(yta).^2;

I = resample(I,2,1);
I1 = log(I);
I1 = imag(hilbert(real(I1)));
phase = theta + I1/(2);
zt_shift = (sqrt(I).*exp(1j*phase));
zt_shift = resample(zt_shift,1,2);
zt_shift = zt_shift - mean(zt_shift);
% zt_shift = abs(yta).^2 - abs(zt_shift).^2;
% zt_shift = zt_shift - mean(zt_shift);
% zt_shift = IdealFilter(zt_shift,fs,(1+beta)*0.5*fs/NperSym,B);
% zt_shift = DspKK(I,A);
zt = zt_shift.*exp(-1j*2*pi*B*t);

rc = rc(end:-1:1); 
yrt = conv(yt,rc);
yrk = downsample(yrt,NperSym,0);
zrt = conv(zt,rc);
zrk = downsample(zrt,NperSym,0);
% 
% figure(1); clf;
% subplot(2,1,1); plot(t,real(yt),':',t,real(zt)); axis([0 4 -2 2]);
% subplot(2,1,2); plot(t,imag(yt),':',t,imag(zt)); axis([0 4 -2 2]);

figure(2); clf;
subplot(2,1,1); plot((1:81),real(yrk),'-+',(1:81),real(zrk),'-o');grid on
subplot(2,1,2); plot((1:81),imag(yrk),'-+',(1:81),imag(zrk),'-o');grid on
% pause
% 
MM = [-3+3*j -3+1*j -3-3*j -3-1*j -1+3*j -1+1*j -1-3*j -1-1*j +3+3*j +3+1*j +3-3*j +3-1*j +1+3*j +1+1*j +1-3*j +1-1*j];
for km = 1:16
    km
    kk=7; yt1 = yt; yt1(kk*NperSym+1:kk*NperSym+length(rc)) = yt1(kk*NperSym+1:kk*NperSym+length(rc))+MM(km)*rc;
    yt1_shift = yt1.*exp(1j*2*pi*B*t);
    A = mag*max(abs(yt1_shift))*exp(j*theta);
    yt1a = yt1_shift + A;
    I = abs(yt1a).^2;
    
    I = resample(I,2,1);
    I1 = log(I);
    I1 = - imag(hilbert(-real(I1)));
    phase = theta + I1/(2);
    zt1_shift = (sqrt(I).*exp(1j*phase));
    zt1_shift = resample(zt1_shift,1,2);
    zt1_shift = zt1_shift - mean(zt1_shift);
%     zt1_shift = abs(yt1a).^2 - abs(zt1_shift).^2;
%     zt1_shift = zt1_shift - mean(zt1_shift);
%     zt1_shift = IdealFilter(zt1_shift,fs,(1+beta)*0.5*fs/NperSym,B);
    zt1 = zt1_shift.*exp(-1j*2*pi*B*t);
%     zt1_shift = DspKK(I,A);
%     zt1 = zt1 - yt1;
%     zt1 = MyAlgorithm(zt1,0,mag);


%     figure(1); clf;
%     subplot(2,1,1); plot(t,real(yt),':',t,real(zt),t,real(yt1),':',t,real(zt1)); axis([0 4 -2 2]);
%     subplot(2,1,2); plot(t,imag(yt),':',t,imag(zt),t,imag(yt1),':',t,imag(zt1)); axis([0 4 -2 2]);
    figure(1); clf;
%     subplot(2,1,1); plot(t,real(yt1),'r:',t,real(zt1),'c-',t,real(zt2),'k--'); axis([0 2 -2 2]);
%     subplot(2,1,2); plot(t,imag(yt1),'r:',t,imag(zt1),'c-',t,imag(zt2),'k--'); axis([0 2 -2 2]);
    subplot(2,1,1); plot(t,real(yt1),'r:',t,real(zt1),'c-'); axis([0 2 -2 2]);title('�ź�ʵ��'); legend('Դ�ź�','�ָ����ź�');
    subplot(2,1,2); plot(t,imag(yt1),'r:',t,imag(zt1),'c-'); axis([0 2 -2 2]);title('�ź��鲿'); legend('Դ�ź�','�ָ����ź�');
    pause
end



