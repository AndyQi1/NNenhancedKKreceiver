function PhaseInfoSignal = AddPhaseInfo(OriSignal,PhaseT,type,weight)
if nargin < 4
    weight = 1;
else
    weight = max(max(OriSignal))*weight;
end
if strcmp(type,'eye')
    PhaseMat = eye(PhaseT)*weight;
else
    PhaseMat = [1:PhaseT]*weight;
end
SigLen = length(OriSignal(1,:));
PhaseMat = repmat(PhaseMat,1,ceil(SigLen/PhaseT));
PhaseMat = PhaseMat(:,1:SigLen);
PhaseInfoSignal = [PhaseMat;OriSignal];